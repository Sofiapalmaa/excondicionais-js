// let numero = prompt("Digite um número: ");
// console.log(numero);
// numero = parseInt(numero)
// numero === 0
// if (numero > 0){
//     console.log("O número é positivo.");
// } else if (numero < 0) {
//     console.log("O número é negativo.");
// } else {
//     console.log("O número é igual a 0.");
// }

// let numero = prompt("Digite um número: ");
// console.log(numero);
// numero = parseInt(numero)
// if (numero %2 == 0){
//     console.log("O número é par.")
// } else {
//     console.log("O número é ímpar.")
// }

// let idade = prompt("Digite a sua idade: ");
// console.log(idade);
// idade = parseInt(idade)
// if (idade <= 12){
//     console.log("Você é criança.")
// } else if (idade >= 13 && idade <= 17) {
//     console.log("Você é adolescente.")
// } else {
//     console.log("Você é adulto.")
// }

// let nota = prompt("Nota: ");
// console.log(nota);
// nota = parseInt(nota)
// if (nota >= 60 && nota < 101){
//     console.log("Aprovado(a)!")
// } else if (nota < 60) {
//     console.log("Reprovado(a)!")
// } else {
//     console.log("Nota inválida. Digite novamente.")
// }


let number1 = prompt("Digite o primeiro número:");
let number2 = prompt("Digite o segundo número:");
let operacao = prompt("Digite a operação (+, -, *, /):");
number1 = parseFloat(number1)
number2 = parseFloat(number2)

let resultado;

switch(operacao) {
    case '+':
        resultado = number1 + number2;
        console.log(`O resultado da soma é: ${resultado}`);
        break;
    
    case '-':
        resultado = number1 - number2;
        console.log(`O resultado da subtração é: ${resultado}`);
        break;
    
    case '*':
        resultado = number1 * number2;
        console.log(`O resultado da multiplicação é: ${resultado}`);
        break;
    
    case '/':
        if (number2 !== 0) {
            resultado = number1 / number2;
            console.log(`O resultado da divisão é: ${resultado}`);
        } else {
            console.log("Erro: Divisão por zero!");
        }
        break;
    
    default:
        console.log("Operação inválida! Escolha entre +, -, * ou /.");
}
